//
//  VerveAd.h
//  VerveAd
//
//  Created by Sam Boyce on 11/6/18.
//  Copyright © 2018 Sam Boyce. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for verveSDK.
FOUNDATION_EXPORT double verveSDKVersionNumber;

//! Project version string for verveSDK.
FOUNDATION_EXPORT const unsigned char verveSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <verveSDK/PublicHeader.h>
#import <VerveAd/VRVInterstitialAd.h>
#import <VerveAd/VRVRewardedAd.h>
#import <VerveAd/VRVBannerAdView.h>

